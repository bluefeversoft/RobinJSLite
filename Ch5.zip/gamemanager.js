var res = {};

res.BG_IMAGE = 'images/BG-HD.png';
res.FLOOR_IMAGE = 'images/Floor-HD.png';
res.ROBIN_IMAGE = 'images/Robin-HD.png';

var kZindexBG = 0;
var kZindexFloor = 40;
var kZindexRobin = 100;

var kRobinStateStopped = 0;
var kRobinStateMoving = 1;
var kRobinStartSpeedY = 300;
var kRobinStartX = 240;

var GRAVITY = -620;


