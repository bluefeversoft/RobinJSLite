var res = {};

res.BG_IMAGE = 'images/BG-HD.png';
res.FLOOR_IMAGE = 'images/Floor-HD.png';

var kZindexBG = 0;
var kZindexFloor = 40;

