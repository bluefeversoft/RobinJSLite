var GameLayer = cc.Layer.extend({
	ctor:function() {
		this._super();
		this.init();
	},
	init:function() {
		this._super();
		var size = cc.director.getWinSize();
	
		var bgsprite = cc.Sprite.create(res.BG_IMAGE);
		bgsprite.setPosition(size.width / 2, size.height / 2);
		this.addChild(bgsprite, kZindexBG);
		
		this._floor = cc.Sprite.create(res.FLOOR_IMAGE);
		this._floor.setPosition(0, 0);
		this._floor.setAnchorPoint(0,0);
		this.addChild(this._floor, kZindexFloor);
		
	},
	onEnter:function() {
		this._super();		
	},

});

GameLayer.scene = function() {
	var scene = new cc.Scene();
	var layer = new GameLayer();
	scene.addChild(layer);
	return scene;
}

window.onload = function(){

	var targetWidth = 960;
	var targetHeight = 640;
	
    cc.game.onStart = function(){
		
		cc.view.adjustViewPort(false);
		cc.view.setDesignResolutionSize(targetWidth, targetHeight, cc.ResolutionPolicy.SHOW_ALL);
		cc.view.resizeWithBrowserSize(true);
		//load resources
		cc.LoaderScene.preload(["images/HelloWorld.png"], function () {                  
		cc.director.runScene(GameLayer.scene());
	  }, this);
    };
    cc.game.run("gameCanvas");
};
		  
	



























	
		  
		  
		  